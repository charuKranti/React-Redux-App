//for installation and react app creation
npx create-react-app appname
//for router installation
npm install --save react-router-dom
//for state management installtion
npm install redux
// for comobine react with redux
npm install react-redux
//for bootstrap
npm install --save bootstrap