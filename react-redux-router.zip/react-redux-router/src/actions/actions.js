// this is for adding item
import axios from 'axios';
//import AxiosAPI from "../utils/AxiosAPI";
/* This action for login Request  */
export const loginRequest = (user) => dispatch => {
  /*
    try {
      // Load async data from an inexistent endpoint.
      let userData = await AxiosAPI.get("/userlist");
    } catch (e) {
      //console.log(`Axios request failed: ${e}`);
    }
*/
  axios.post(`https://jsonplaceholder.typicode.com/users`, { user })
  .then(res => {
      console.log("LoggedIn: ",res.data);
      dispatch({
        type:"LOGIN_REQUEST",
        payload:res.data
      })
  })
};

export const addUser = (name) => ({
    type: "ADD_USER",
    id: parseFloat((Math.random()*2).toString().slice(2)),
    name
});

// this for removing item
export const deleteUser = (id) =>({
    type: "DELETE_USER",
    id
});



// pull rest API data on button click
export const fetchData = () => dispatch => {
   console.log("Action: ");
  /*
   fetch('https://jsonplaceholder.typicode.com/todos').then(res => res.json()).then(res => 
     dispatch({
       type:"FETCH_DATA",
       payload:res
     })
   )
  */

  axios.get('https://jsonplaceholder.typicode.com/todos')
      .then(res => {
         console.log("Action: ",res);
         dispatch({
           type:"FETCH_DATA",
           payload:res.data
         })
      })
};

// pull data on load
export const getDataOnLoad = (response) =>({
    type: "FETCH_ONLOAD",
    payload:response
});
export const fetchDataOnLoad = () => {
   console.log("Action load: ");
   return fetch('https://jsonplaceholder.typicode.com/todos')
};

