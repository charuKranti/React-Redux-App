import React from "react";
import AddComponent from "../../components/useradd";
import ListComponent from '../../components/list';
const Home = () => {
  return (
    <div>
      Home works
      <AddComponent />
      <ListComponent />
    </div>
  );
};
export default Home;