const initialState = {
    errors: [],
    policies: [
       {"id":parseFloat((Math.random()*2).toString().slice(2)),"completed":"No","title":"Ramana"},
       {"id":parseFloat((Math.random()*2).toString().slice(2)),"completed":"Yes","title":"Kumar"},
       {"id":parseFloat((Math.random()*2).toString().slice(2)),"completed":"No","title":"Sravan"}
    ],
    searches: {},
    selectedPolicy: ''
};

const todos = (state = initialState, action) => {
    switch (action.type) {
      case "ADD_USER":
        return  {
          ...state,
          policies:[
            ...state.policies,
            {
              id: action.id,
              complete: action.completed,
              title: action.name
            }
          ]
        }
      case "DELETE_USER":
        return {
          ...state,
          policies:state.policies.filter((item)=> item.id !== action.id)
        }
      case "FETCH_DATA":
        console.log("payload: ",action.payload);
        return {
          ...state,
          policies:action.payload
        }
      case "FETCH_ONLOAD":
        console.log("onLoad: ",action.payload);
        return {
          ...state,
          policies:action.payload
        }
      default:
        return state;
    }
  };
  export default todos;