import axios from 'axios';
//https://stackoverflow.com/questions/43210516/how-to-redirect-from-axios-interceptor-with-react-router-v4
// You can use any cookie library or whatever
// library to access your client storage.
//import cookie from 'cookie-machine';

export default {
  interceptors: (store) => {
const {getState} = store;
console.log("Store: ",getState());
      // request interceptors
      axios.interceptors.request.use(function(config) {
        const token = 'cookie.get(__TOKEN_KEY__)';
        if ( token != null ) {
          console.log("testing");
          config.headers.Authorization = `Bearer ${token}`;
        }

        return config;
      }, function(err) {
        return Promise.reject(err);
      });

      //response interceptors
      axios.interceptors.response.use(response => {
        return response;
      }, error => {
        if (error['response']['status'] === 401) {
          //store.dispatch(logoutUser());
        }

        if (error['response']['status'] === 404) {
          //history.push('/not-found');
        }

        return Promise.reject(error);
    });
  },
};