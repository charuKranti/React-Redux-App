import axios from "axios";

/*  setting main base url  */
export default axios.create({
  baseURL: "http://localhost:4546/api/"
});