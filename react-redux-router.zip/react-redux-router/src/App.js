import React from 'react';
import Home from './pages/home/home';
import {
  Switch,
  Route,
  withRouter,
  NavLink,
  Redirect
} from "react-router-dom";

const App = withRouter(
   
   class extends React.Component {
      componentDidMount() {
         console.log("MOUNTED ", this.props.location.pathname);
         this.unlisten = this.props.history.listen(location => {
            console.log("PREPARING NAVIGATE TO ", location.pathname);
         });
      }

      componentWillUnmount() {
         this.unlisten();
      }

      render() {
        return (
          <div className="App">
            <div>
              <NavLink to="/home">Home</NavLink>
            </div>
            <hr />
            <Switch>
              <Route path="/home" component={Home} />
              <Redirect to="/home" />
            </Switch>
          </div>
        );
      }
   }//Class End

);




export default App;
