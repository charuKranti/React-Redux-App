import React, {useEffect} from "react";
//import PropTypes from 'prop-types';
import {addUser,fetchData,fetchDataOnLoad,getDataOnLoad} from '../actions/actions';
import { connect } from "react-redux";



const AddComponent = ({ todos, dispatchEvent, totalState, dispatchEvent2, dispatchEOnload,location }) => {
 
useEffect(() => {
   fetchDataOnLoad().then(res=>res.json()).then(res=>dispatchEOnload(res));
   dispatchEvent2();
   
}, [dispatchEvent2,dispatchEOnload]);

//empty array [] in useeffect is not safe include any prop ex: dispatchEOnload
//https://reactjs.org/docs/hooks-faq.html#is-it-safe-to-omit-functions-from-the-list-of-dependencies
  let element;
  let addItem = (e) => {
    console.log("data: ",totalState);
    if (element.value.trim() !== "" && (todos.findIndex((item)=>item.title === element.value) === -1) ) {
      //dispatch(addUser(element.value.trim()));
      dispatchEvent(element.value)
      element.value="";
    }
  };

  let fetchApi= (e) =>{
     console.log("Event: ");
     dispatchEvent2();
  }
  return (
    <>
      <input type="text" ref={node => (element = node)} />
      <button type="submit" onClick={addItem}>
        Add Item
      </button>
     <button onClick={fetchApi}>Fetch</button>
    </>
  );
};
// this is for adding props (state) to AddComponent
const mapStateToProps = state => ({
  todos: state.todos.policies,
  totalState: state.todos
});


const mapDispatchToProps = dispatch => ({
  dispatchEvent: item => dispatch(addUser(item)),
  dispatchEvent2: () => dispatch(fetchData()),
  dispatchEOnload: (res) => dispatch(getDataOnLoad(res))
});

export default connect(mapStateToProps,mapDispatchToProps)(AddComponent);