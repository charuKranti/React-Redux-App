import React from "react";

import DeleteEelement from './deleteList';
const ListItemComponent = ({ title,id }) => {
  return (
    <li className="list-group-item">
      {title}
        <DeleteEelement id={id} />
    </li>
  );
};

export default ListItemComponent;