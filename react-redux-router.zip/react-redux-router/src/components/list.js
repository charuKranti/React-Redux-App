import React from "react";
import ListItemComponent from "./listItem";
import { connect } from "react-redux";
const ListComponent = ({ todos }) => {
  return (
    <ul className="list-group" style={{width: '350px',margin:'15px'}}>
      {todos != null &&
        todos.map(todo => (
          <ListItemComponent key={todo.id} {...todo} />
        ))}
    </ul>
  );
};

const mapStateToProps = state => ({
  todos: state.todos.policies
});

// const mapDispatchToProps = dispatch => ({
//   toggleTodo: id => dispatch(toggleTodo(id))
// });

export default connect(mapStateToProps, {})(ListComponent);
