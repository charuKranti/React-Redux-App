import React from "react";
import { deleteUser } from "../actions/actions";
import { connect } from "react-redux";

/*
const DeleteEelement = ({ dispatch,id }) => {
  let deleteTask = (id) => {
    if (id) {
      console.log('delete: ',id)
      dispatch(deleteUser(id));
    }
  };
  return (
    <React.Fragment>
      <button type="submit" onClick={()=>deleteTask(id)}>
        X
      </button>
    </React.Fragment>
  );
};

export default connect()(DeleteEelement);

*/

class DeleteEelement extends React.Component{
  deleteTask=(id)=>{
    console.log('delete: ',id);
    this.props.dispatch(deleteUser(id));
  }
  render(){
    return (
      <React.Fragment>
      <button className="float-right" type="submit" onClick={()=>this.deleteTask(this.props.id)}>
        X
      </button>
    </React.Fragment>
    )
  }
}

export default connect()(DeleteEelement);